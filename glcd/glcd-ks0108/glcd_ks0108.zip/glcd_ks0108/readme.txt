AVRgcc - KS0108 Library
=========================

Version 1.1

Die Library bietet ein paar elementare Grafikfunktionen und unterst�tzt
verschiedene Schriftarten. Die Schriftarten k�nnen mit meinem FontEditor
erstellt werden.

Die Dokumentation l�sst noch etwas zu w�nschen �brig. Wenn ich mal etwas
Zeit er�brigen kann wird sie aber noch vertieft :)
Das beiliegende Demoprogramm zeigt den Umgang mit den Fonts, die
restlichen Funktionen sollten dann eigentlich einigerma�en
selbsterkl�rend sein. Ansonsten stehe ich nat�rlich f�r Fragen zur
Verf�gung.
Weitere Informationen und der FontEditor sind auf meiner Homepage zu
finden.

Das Demo-Programm ist f�r den mega128 geschrieben. Um es f�r einen
anderen AVR zu kompilieren m�ssen aber nur der MCU-Typ im makefile und
die Port-Definitionen in der ks0108.h angepast werden.

Lizenz: gibts nich wirklich. Wer meine Lib in einem privaten Projekt
verwenden oder ver�ndern m�chte soll das tun. Bei einem kommerziellen
Projekt w�rde ich mich �ber eine R�ckfrage freuen. In jedem Fall muss
aber mein Copyright erhalten bleiben.


Fabian Maximilian Thiele
me@apetech.de
http://www.apetech.de