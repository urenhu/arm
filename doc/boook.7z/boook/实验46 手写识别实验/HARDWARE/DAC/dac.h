#ifndef __DAC_H
#define __DAC_H	 
#include "sys.h"	    
								    

void Dac_Init(void);//�ػ�ģʽ��ʼ��		 	 
void Dac_Set_Vol(u16 vol);
#endif

















